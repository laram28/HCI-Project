package com.example.hci_project;

public class ItemColors {

    private String question, answer;

    public ItemColors(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }
}
