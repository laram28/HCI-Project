package com.example.hci_project;

public class DatabaseColors {

    public static String quizInfo[][] = {
            {"bluecircle", "blue", "red", "green", "yellow"},
            {"greentriangle", "green", "red", "blue", "yellow"},
            {"redsquare", "red", "yellow", "green", "blue"},
            {"yellowrectangle", "yellow", "red", "green", "blue"}
    };
}
