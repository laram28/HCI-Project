package com.example.schoolsubjects;

public class DatabaseMath {
        public static String[] questions = {
                "1 + 0 = ",
                "1 + 1 = ",
                "2 + 1 = ",
                "2 + 2 = ",
                "3 + 2 = "
        };

        public static String[] answers = {
                "1",
                "2",
                "3",
                "4",
                "5"
        };
}
