package com.example.schoolsubjects;

public class DatabaseWords {

    public static String[] questions = {
            "edr",
            "dgo",
            "atc",
            "woc",
            "doog"
    };

    public static String[] answers = {
            "red",
            "dog",
            "cat",
            "cow",
            "good"
    };
}