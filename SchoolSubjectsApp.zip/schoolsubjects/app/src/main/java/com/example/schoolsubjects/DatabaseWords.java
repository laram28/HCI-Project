package com.example.schoolsubjects;

public class DatabaseWords {

    //String Array questions
    public static String[] questions = {
            "edr",
            "dgo",
            "atc",
            "woc",
            "doog"
    };

    //String Array answers
    public static String[] answers = {
            "red",
            "dog",
            "cat",
            "cow",
            "good"
    };
}