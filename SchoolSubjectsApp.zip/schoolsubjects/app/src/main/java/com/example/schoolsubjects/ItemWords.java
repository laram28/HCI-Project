package com.example.schoolsubjects;

public class ItemWords {

    private String question, answer;

    public ItemWords(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    public String getQuestion() {

        return question;
    }

    public String getAnswer() {

        return answer;
    }
}
