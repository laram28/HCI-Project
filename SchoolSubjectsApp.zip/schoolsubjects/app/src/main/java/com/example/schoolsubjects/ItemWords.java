package com.example.schoolsubjects;

public class ItemWords {

    private String question, answer;

    public ItemWords(String question, String answer) {
        //Refer the current instance of the method
        this.question = question;
        this.answer = answer;
    }

    //Getters
    public String getQuestion() { return question; }

    public String getAnswer() { return answer; }
}
